
import { useEffect, useState } from "react";
import api from "../api/api";

export default function Dashboard() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    api.get("/students").then(res => setStudents(res.data));
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      {students.map(s => (
        <div key={s._id}>{s.name} - {s.regNo}</div>
      ))}
    </div>
  );
}
