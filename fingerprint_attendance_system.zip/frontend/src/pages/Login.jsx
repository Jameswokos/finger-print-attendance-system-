
import { useState } from "react";
import api from "../api/api";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const login = async (e) => {
    e.preventDefault();
    const res = await api.post("/auth/login", { username, password });
    localStorage.setItem("token", res.data.token);
    alert("Logged in");
  };

  return (
    <div>
      <form onSubmit={login}>
        <input placeholder="username" onChange={(e)=>setUsername(e.target.value)} />
        <input placeholder="password" onChange={(e)=>setPassword(e.target.value)} />
        <button>Login</button>
      </form>
    </div>
  );
}
