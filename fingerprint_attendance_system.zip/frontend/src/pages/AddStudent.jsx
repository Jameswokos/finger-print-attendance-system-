
import { useState } from "react";
import api from "../api/api";

export default function AddStudent() {
  const [form, setForm] = useState({ name: "", regNo: "", fingerprintId: "" });

  const submit = async (e) => {
    e.preventDefault();
    await api.post("/students", form);
    alert("Added");
  };

  return (
    <form onSubmit={submit}>
      <input placeholder="name" onChange={e=>setForm({...form, name:e.target.value})} />
      <input placeholder="regNo" onChange={e=>setForm({...form, regNo:e.target.value})} />
      <input placeholder="fingerprintId" onChange={e=>setForm({...form, fingerprintId:e.target.value})} />
      <button>Save</button>
    </form>
  );
}
