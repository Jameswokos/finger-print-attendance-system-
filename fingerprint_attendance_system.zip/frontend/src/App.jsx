
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AddStudent from "./pages/AddStudent";

export default function App() {
  return (
    <div>
      <Login />
      <Dashboard />
      <AddStudent />
    </div>
  );
}
