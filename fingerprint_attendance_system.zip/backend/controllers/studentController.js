
import Student from "../models/Student.js";

export const addStudent = async (req, res) => {
  const data = await Student.create(req.body);
  res.json(data);
};

export const getStudents = async (req, res) => {
  const data = await Student.find();
  res.json(data);
};
