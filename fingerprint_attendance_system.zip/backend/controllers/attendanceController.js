
import Attendance from "../models/Attendance.js";

export const markAttendance = async (req, res) => {
  const data = await Attendance.create(req.body);
  res.json(data);
};

export const getAttendance = async (req, res) => {
  const data = await Attendance.find();
  res.json(data);
};
