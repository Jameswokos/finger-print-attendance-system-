
import mongoose from "mongoose";

const schema = new mongoose.Schema({
  name: String,
  regNo: String,
  fingerprintId: String,
});

export default mongoose.model("Student", schema);
