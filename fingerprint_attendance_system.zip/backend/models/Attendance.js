
import mongoose from "mongoose";

const schema = new mongoose.Schema({
  studentId: String,
  date: String,
  time: String,
  status: String,
});

export default mongoose.model("Attendance", schema);
